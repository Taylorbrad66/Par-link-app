ParLink V1.2 GitHub upload package.
Upload all files in this folder to the ROOT of the Taylorbrad66/Par-link-app repository on branch main.
Do not upload the ZIP itself. Vercel will deploy automatically after the commit.
